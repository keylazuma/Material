##XS-2110 M�todos Estad�sticos

##Laboratorio de prueba de hip�tesis para dos poblaciones: Muestras independientes.

##El objetivo de este laboratorio es realizar las siguientes pruebas de hip�tesis para dos poblaciones en R:
#	Prueba t
#	Wilcoxon (U Mann Whitney)
#	Kruskal Wallis
#	Kolmogorov Smirnov para 2 muestras independientes.
#	Proporciones
#	Chi-cuadrado
#	Test Fisher


#Los datos que vamos a utilizar se encuentran en el archivo mhasbasico.dta
mhasbasico=load("mhasbasico.Rdata")
names(mhasbasico)

attach(mhasbasico)

#Estad�sticas descriptivas de la variable ingreso
summary(income.i)
length(income.i)

#Para quitar ingreso ignorado

ingreso=na.omit(income.i)

summary(ingreso)
length(ingreso)

#Se eliminan de la base de datos aquellos registros que tienen
#NA en la variable ingreso
dim(mhasbasico)

mhasbasico2=subset(mhasbasico, is.na(income.i)==F)
mhasbasico3=na.omit(mhasbasico)
dim(mhasbasico2)
dim(mhasbasico3)

detach(mhasbasico)

attach(mhasbasico2)


#Recodificaci�n de la variable migraci�n
table(a25)
library(car)
##migracion=as.factor(recode(a25, "1=1; 2=0; 8=NA"))
t(t(table(migracion)))

##Vamos a realizar una prueba t de diferencia de medias en ingreso (income.i)
##seg�n migraci�n

library(car)

##H0: Var1=Var2
##H1: Var1<>Var2

leveneTest(income.i,migracion)


###H0: Mu1=Mu2
###H1: Mu1<>Mu2

t.test(income.i[migracion==0],income.i[migracion==1], alternative= "two.sided", mu=0, var.equal=F)

t.test(income.i[migracion==0])
t.test(income.i[migracion==1])

shapiro.test(income.i[migracion==0])

shapiro.test(income.i[migracion==1])

#Wilcoxon-Mann-Whitney


###H0: Mu1=Mu2   ==>  H0: F(X1)=F(X2)
###H1: Mu1<>Mu2  ==> H1: F(X1)<> F(X2)



wilcox.test(income.i[migracion==0],income.i[migracion==1], alternative= "two.sided", mu=0, paired=F)

#Kruskal - Wallis

kruskal.test(income.i~migracion)

##Que hubiera pasado si las variancias hubieran sido iguales

t.test(income.i[migracion==0],income.i[migracion==1], alternative= "two.sided", mu=0, var.equal=T)

##Comparar con ANOVA

anova.ingreso=(lm(income.i~migracion))
anova(anova.ingreso)

####Otra prueba no param�trica: 
##KolmogorovSmirnov para dos muestras independientes

###H0: Mu1=Mu2   ===> H0: F(Y1)=F(Y2)
###H1: Mu1<>Mu2  ===> H1: F(Y1)<>F(Y2)

ks.test(income.i[migracion==0],income.i[migracion==1])


##Ahora analizaremos pruebas de hip�tesis para dos proporciones

median(income.i, na.rm=TRUE)

###ingreso.median=recode(income.i, "-2000000:1252.083=0; 1252.083:100000000=1")

t(t(table(ingreso.median)))

ingreso.por.migracion=table(ingreso.median,migracion)

ingreso.por.migracion

#Prueba Chi cuadrado


###H0: P1=P2
###H1: P1<>P2

chisq.test(ingreso.por.migracion)



#Prueba exacta de Fisher
fisher.test(ingreso.median,migracion)

fisher.test(ingreso.por.migracion)

table(migracion)
ingreso.por.migracion
#Prueba para dos proporciones

prop.test(c(1327,136),c(2664,263))



##H0: Mu1=Mu2
maq1=c(8.26,8.13,8.385,8.07,8.34)
maq2=c(7.95,7.89,7.9,8.14,7.92,7.84)

maq.total=c(maq1,maq2)
tipo=as.factor(c(rep(1,5),rep(2,6)))

par(mfrow=c(1,2))
qqPlot(maq1)
qqPlot(maq2)

shapiro.test(maq1)
shapiro.test(maq2)

##H0: Mu1=Mu2
##H1: Mu1<>Mu2

###a)
wilcox.test(maq1,maq2,paired=F)

##b)
##H0: Var1=Var2
##H1: Var1<> Var2

leveneTest(maq.total,tipo)


##c)
t.test(maq1,maq2,paired=F,var.equal=T)
