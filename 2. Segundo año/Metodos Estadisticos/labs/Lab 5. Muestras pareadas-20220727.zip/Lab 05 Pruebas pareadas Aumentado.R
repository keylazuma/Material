#XS-2110 M?todos Estad?sticos

#Laboratorio 5. Pruebas en muestras pareadas



library(car)


#######################Ejemplo clase anterior#####################

###Prueba t-pareada###

###Suponga que tiene a 10 pacientes hipertensos a los cuales 
### se les receta una medicina nueva para controlar la presi?n arterial.  
###Se tiene la medici?n de la presi?n sist?lica antes de la receta
###y tres semanas despu?s de estar tomando la medicina.

###El objetivo es analizar si la medicina ayud? a reducir la presi?n sist?lica


ps.antes=c(140,150,167,180,210,110,125,133,158,170)

ps.despues=c(135,148,133,185,190,110,130,90,145,160)



###H0: Mu_antes=Mu_despues :  H0: Mu_dif=0

t.test(ps.antes,ps.despues,paired=T)
##H1: Mu_antes<>Mu_despues

t.test(ps.antes,ps.despues,paired=T, alternative = "greater")
###H1: Mu_antes>Mu_despues
t.test(ps.despues,ps.antes,paired=T, alternative = "less")
###H1: Mu_despues<Mu_antes



diferencia=ps.antes- ps.despues

t.test(diferencia, alternative = "greater")
###H0: Mu_dif=0
##H1: Mu_dif>0

par(mfrow=c(1,2))

qqPlot(ps.despues)

qqPlot(ps.antes)



qqPlot(diferencia)

shapiro.test(diferencia)



######################Prueba de rangos de Wilcoxon#####################
### Se usa el mismo comando que la U de Mann Whitney###


#ps.antes=c(140,150,167,180,210,110,125,133,158,170)

#ps.despues=c(135,148,133,185,190,110,130,90,145,160)

#wilcox.test(ps.despues,ps.antes,paired=T)
#wilcox.test(ps.antes,ps.despues,paired=T)

wilcox.test(ps.antes,ps.despues,paired=T, alternative = "greater")
###H1: Mu_antes>Mu_despues

diferencia







########################prueba signos##########################


#Ejemplo clase anterior# 

#ps.antes=c(140,150,167,180,210,110,125,133,158,170)

#ps.despues=c(135,148,133,185,190,110,130,90,145,160)


difej1=ps.antes- ps.despues

summary(difej1)

difej1rec=Recode(difej1,"-5:-1=-1;0=NA;1:43=1")

table(difej1rec)
signosej1<-binom.test(7,9,p=0.5, alternative = "greater")
###H1: Mu_antes>Mu_despues

signosej1







#######################Ejemplos Mendenhall #####################
################EJEMPLO GEMELOS##############

#Ejercicio 15.57
#Para comparar dos escuelas secundarias, A y B, en efectividad acad?mica, 
#se dise?? un experimento que requer?a el uso de 10 pares de gemelos id?nticos, 
#donde cada gemelo acababa de terminar el sexto grado. En cada caso, los gemelos 
#del mismo par hab?an tenido su ense?anza en los mismos salones de clase en cada 
#nivel de grado. Un ni?o fue seleccionado al azar de cada par de gemelos
#y asignado a la escuela A. Los dem?s ni?os fueron enviados a la escuela B. 
#Cerca del final del noveno grado, se aplic? cierto examen de aprovechamiento a cada 
#ni?o del experimento. 

#Pruebe la hip?tesis de que las dos escuelas son iguales en efectividad acad?mica, 
#medida por calificaciones en el examen de aprovechamiento, contra la alternativa de que 
#las escuelas no son igualmente efectivas. Use la prueba t pareda, la prueba de signos 
#y la prueba Wilcoxon



A<-c(67, 80, 65, 70, 86, 50, 63, 81, 86, 60)
B<-c(39, 75, 69, 55, 75, 52, 56, 72, 89, 47)

###H0: Mu(A)=Mu(B)
###H1: Mu(A)<>Mu(B)


#Wilcoxon
wilcox.test(B, A, paired=TRUE, correct=FALSE)

#prueba t pareada

t.test(A,B,paired=TRUE)
difab<-A-B

#signos
table(difab)
difabrecode<-recode(difab,"-4:-1=-1;0=NA;1:28=1")
table(difabrecode)
signosab<-binom.test(7,10,p=0.5)
signosab


shapiro.test(difab)
qqPlot(difab)







################Prueba de McNemar###################

presion<-matrix(c(38,33,4,35),nrow=2, dimnames=list("Antes"=c("Controlado", "No controlado"), "Despues"=c("Controlado", "No controlado")))
presion
##H0: P1=P2
##H1: P1<>P2

mcnemar.test(presion,correct=FALSE)

###Prop(controlados_antes)=(38+4)/110
(38+4)/110

###Prop(controlados_despues)=(38+33)/110
(38+33)/110

presion

binom.test(33,37,p=.5)
binom.test(4,37,p=.5)








#######################Ejemplos Mendenhall #####################

#Ejemplo 10.5
#Para comparar las cualidades de desgaste de dos tipos de llantas de autom?vil,
#A y B, una llanta de tipo A y una de tipo B se asignaron al azar y se montaron 
#en las ruedas traseras de cada uno de cinco autom?viles. Estos se hicieron correr 
#un n?mero especificado de millas y se registr? la cantidad de desgaste para cada llanta.
#?Los datos presentan suficiente evidencia para indicar una diferencia en el 
#promedio de desgaste para los dos tipos de llantas?

#H0: mu(tipoa)=mu(tipob)
#H1: mu(tipoa)<>mu(tipob)

tipoA<-c(10.6, 9.8, 12.3, 9.7, 8.8)
tipoB<-c(10.2, 9.4, 11.8, 9.1, 8.3)
dif10.5<-tipoA-tipoB

qqPlot(dif10.5)



shapiro.test(dif10.5)


t.test(tipoA, tipoB, paired=TRUE)
t.test(dif10.5)





#Ejemplo 10.45
#En respuesta a una queja de que un asesor de impuestos en particular (A) estaba sesgado,
#se realiz? un experimento para comparar al asesor citado en la queja con otro asesor de 
#impuestos (B) de la misma oficina. Se seleccionaron ocho propiedades y cada una fue evaluada
#para ambos asesores. 


asesorA<- c(76.3, 88.4, 80.2, 94.7, 68.7, 82.8, 76.1, 79.0)
asesorB<- c(75.1, 86.8, 77.3, 90.6, 69.1, 81.0, 75.3, 79.1)
difasesores<-asesorA-asesorB
##H0: Mu(A)=Mu(B)
##H1: Mu(A)>Mu(B)

qqPlot(difasesores)

t.test(asesorA,asesorB,paired = TRUE, alternative = "greater")
table(difasesores) 


#Ejemplo 10.46
#Experimentos de memoria. Un grupo de psicolog?a realiz? un experimento para comparar si una 
#calificaci?n de recordatorio, en la que se dieron instrucciones para formar im?genes
#de 25 palabras, es mejor que una calificaci?n inicial de recordatorio para la cual no se 
#dieron instrucciones para formar im?genes. Veinte estudiantes participaron en el experimento.

con<-c(20, 24, 20, 18, 22, 19, 20, 19, 17, 21, 17, 20, 20, 16, 24, 22, 25, 21, 19, 23)
sin<-c(5, 9, 5, 9, 6, 11, 8, 11, 7, 9, 8, 16, 10, 12, 7, 9, 21, 14, 12, 13)
t.test(con, sin, paired = TRUE, alternative = "greater")

###H0: Mu(con)=Mu(sin)
###H1: Mu(con)>Mu(sin)










#Ejemplo Mendenhall
#Ejemplo 15.17
#En respuesta a una queja de que un asesor de impuestos en particular (A) estaba sesgado,
#se realiz? un experimento para comparar al asesor citado en la queja con otro asesor de 
#impuestos (B) de la misma oficina. Se seleccionaron ocho propiedades y cada una fue evaluada
#para ambos asesores. 


asesorA<- c(76.3, 88.4, 80.2, 94.7, 68.7, 82.8, 76.1, 79.0)
asesorB<- c(75.1, 86.8, 77.3, 90.6, 69.1, 81.0, 75.3, 79.1)
difasesores<-asesorA-asesorB

table(difasesores)
difasesoresrecode=recode(difasesores,"-0.4:-0.001=-1;0=NA;0.001:5=1")
table(difasesoresrecode)
signosej15.17<-binom.test(6,8,p=0.5)
signosej15.17

difasesores2<-asesorB-asesorA
difasesores2

#otra forma

positivos.ej15.17<-binom.test(6,8,p=0.5, alternative = "greater")
positivos.ej15.17

negativos.ej15.17<-binom.test(2,8,p=0.5, alternative = "less")
negativos.ej15.17

positivos.ej15.17$p.value+negativos.ej15.17$p.value





