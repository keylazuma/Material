#XS-2110 M?todos Estad?sticos
#Laboratorio 3.  Pruebas de hip?tesis para la media de una poblaci?n

#El objetivo del laboratorio es probar hip?tesis para una poblaci?n utilizando las siguientes pruebas en R:
# ???	Kolmogorov Smirnov
#??? 	Shapiro Wilks
#???	Jarque Bera
#???	Prueba t
#???	Prueba binomial exacta
#???	Prueba para una proporci?n
#???	Prueba de mediana


#Se utilizar? la base de datos antropomexicano

install.packages("tseries")

names(antropomexicano)

attach(antropomexicano)

mean(edad)
sd(edad)


#Prueba kolmogorov smirnov   H0: Edad proviene de una poblac normal con Mu=60.3 y sigma=10.6,  alfa=0.05
#alfa=0.05
ks.test(edad,"pnorm",mean(edad),sd(edad))

###Recordar: 
###_Es teóricamente incorrecto estimar la prueba KS con información muestral.
###_Además, se da la advertencia por los empates

table(edad)

summary(edad)

sd(edad)

ks.test(edad,"pnorm",60.31,10.64586)
table(edad)


##Para analizar bondad de ajuste a una distribución normal, sin
##presuponer los valores de los parámetros, se puede usar la 
##prueba de Shapiro-Wilks.

#Prueba Shapiro Wilks  H0: Edad proviene de una poblac normal

shapiro.test(edad)

#Prueba kolmogoro smirnov - distribuci?n exponencial
#H0: Edad proviene de una pob con distr exponencial con tasa=1/60.3
ks.test(edad,"pexp",rate=1/mean(edad))



###Los histogramas pueden servir para analizar la forma distribucional de la variable.
hist(edad)

length(edad)

library(car)

###Tambi?n se puede utilizar el qqPlot.

qqPlot(edad)

#Prueba Jarque Bera

###También está la Prueba Jarque Bera para normalidad


library(tseries)
jarque.bera.test(edad)  ###H0: Edad proviene de una dist normal


#Prueba t

###H0: Mu=60.5
##H1: Mu<>60.5

t.test(edad)  ###Est? malo porque hace falta mu

t.test(edad ,  mu=60.5)

##La alternativa no paramétrica a la prueba t es la prueba de la mediana.  
##Hay que suponer que, por la falta de normalidad, la distribución de la variable
##es asimétrica, por lo que se prefiere a la mediana sobre la media.


#Test Wilcoxon es la prueba de la mediana, una alternativa no param?trica a la prueba t

##H0:Mu_ed=60.5

wilcox.test(edad, mu=60.5)

median(edad)
mean(edad)



###Con este planteamiento es que es correcto realizar Kolmogorov-Smirnov

ks.test(edad,"pnorm",60.5,11)

###H0: Variable edad proviene de una pob con dist normal con mu=60.5 y sigma=11

###H0: Mu=60.5


#Prueba t de una cola

t.test(edad,mu=55.5, alternative="less")

##H0: Mu=55.5
##H1: Mu<55.5   (Si Mu>, alternative=greater)

#Prueba Kolmogorov smirnov de una cola

ks.test(edad,"pnorm",55.5,11, alternative="less")

#Para una proporci?n - con prueba binomial exacta

mean(urbano)


###Hip?tesis nula: P=0.65

binom.test(sum(urbano),length(urbano), p=0.65)  ##No param

#Prueba para una proporci?n
prop.test(sum(urbano),length(urbano), p=0.65)   ##Param


