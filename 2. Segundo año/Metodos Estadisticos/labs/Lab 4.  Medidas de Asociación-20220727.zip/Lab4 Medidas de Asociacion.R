##XS-2110 M�todos Estad�sticos

##Laboratorio de medidas de asociaci�n

##El objetivo de este laboratorio es calcular las siguientes medidas de asociaci�n en R:
#	Prueba X2
#	Coeficiente de contingencia
#	V de Cramer
#	Prueba Fisher
#	Odds ratio
#	Raz�n de correlaci�n (eta)
#	Correlaci�n de Pearson
#	Correlaci�n de rangos de Spearman
#	Coeficiente tao de Kendall



##Cargar mhasbasico.Rdata##
attach(mhasbasico)
names(mhasbasico)
median(income.i, na.rm=TRUE)

library(car)
ingreso.median=Recode(income.i, "-2000000:1252.083=0; 1252.083:100000000=1")
ingreso.median=(income.i>=1252.083)*1


 t(t(table(ingreso.median)))

ingreso.por.migracion=table(ingreso.median,migracion)
ingreso.por.migracion

tapply(ingreso.median,migracion,mean, na.rm=TRUE)

#Prueba X2
###H0: Altos ingresos son independientes de la experiencia migratoria
##H1: Altos ingresos NO son independientes de la experiencia migratoria.


prueba.X2=chisq.test(ingreso.por.migracion)
prueba.X2

names(prueba.X2)
prueba.X2$expected

#Coeficiente de contingencia

C=sqrt(prueba.X2$statistic/(prueba.X2$statistic+length(ingreso.median)) )
C

#Prueba V de Cramer

V=sqrt(prueba.X2$statistic/(length(ingreso.median)))
V

#Prueba Fisher

fisher.test(ingreso.por.migracion, conf.level=.95)
ingreso.por.migracion
#Odds ratio

###H0: Independencia entre dos variables =  P1=P2
prop.test(c(136,1327),c(136+127,1327+1337))

OR=(0.517/(1-0.517))/(0.498/(1-0.498))
OR

#Raz�n de correlaci�n (eta)
library(car)
table(a39)
religion=Recode(a39, "8:9=NA")

religion2=as.factor(religion)
table(religion2)
table(a39)

anova(lm(income.i~religion2))
tapply(income.i,religion2,mean,na.rm=TRUE)

eta=sqrt(1486100000/(1486100000+1727500000000))
eta

plot(income.i~religion2)

##Correlaci�n
plot(income.i,escolaridad)

shapiro.test(income.i)

qqnorm(income.i)
qqline(income.i)


qqnorm(escolaridad)
qqline(escolaridad)

cor(escolaridad, income.i, use="pairwise.complete.obs")

cor(escolaridad,income.i, use="pairwise.complete.obs", method="pearson")

cor(escolaridad,income.i, use="pairwise.complete.obs", method="spearman")

cor(escolaridad,income.i, use="pairwise.complete.obs", method="kendall")

cor.test(escolaridad,income.i, use="pairwise.complete.obs", method="pearson")

cor.test(escolaridad,income.i, use="pairwise.complete.obs", method="spearman")

cor.test(escolaridad,income.i, use="pairwise.complete.obs", method="kendall")


t(t(table(migracion)))

cor(migracion, income.i, use="pairwise.complete.obs")

