###Los objetivos de este laboratorio son:
##a) Ofrecer una introducci�n a la estimaci�n de ecuaciones de regresi�n
##b) Mostrar como el Modelo Lineal General resume la mayor�a de t�cnicas param�tricas
#####estudiadas en este curso.



#La �nica librer�a por usar es car.
library(car)

#Cargar base de datos

load("F:\\metodos 2011\\antropomexicano.Rdata")
attach(antropomexicano)
names(antropomexicano)

#Verificar valores perdidos y recodificarlos

table(peso)
peso2=recode(peso,"995:999=NA")
table(altura)
altura2=recode(altura,"995:999=NA")
table(cintura)
cintura2=recode(cintura,"995:999=NA")
table(cadera)
cadera2=recode(cadera,"995:999=NA")

#Gr�ficos bivariados

par(mfrow=c(1,3))
plot(altura2,peso2)
plot(cintura2,peso2)
plot(cadera2,peso2)

#Estimamos el modelo de regresion meti�ndolo en un objeto

peso.regresion=lm(peso2~altura2+cintura2+cadera2)
summary(peso.regresion)

###En el modelo tenemos cinco contrastes de hip�tesis:

###H0: Beta_0=0
###H0: Beta_1=0
###H0: Beta_2=0
###H0: Beta_3=0
###H0: Beta_1=Beta_2=Beta_3=0



#Estimamos el ANDEVA asociado a la ecuaci�n de regresi�n
anova(peso.regresion)

###Analicemos supuestos del modelo peso.regresion
#Normalidad condicional
qqPlot(peso.regresion$residuals)

shapiro.test(peso.regresion$residuals)

##Ahora homoscedasticidad
###Se busca una nube aproximadamente horizontal

plot(peso.regresion$fitted.values, peso.regresion$residuals)


###Analizar colinealidad


round(cor(cbind(peso2,altura2,cintura2,cadera2),use="pairwise.complete.obs"),3)




#Ahora supongamos que queremos ver las diferencias por sexo
#Primero transformemos sexo a factor y estimemos un modelo de regresi�n nada m�s con sexo

sexo.factor=as.factor(sexo)
peso.regresion2=lm(peso2~sexo.factor)
summary(peso.regresion2)

##H0: Beta_1=0  ==> H0: Mu1=Mu2  ==> H0: Mu1-Mu2=0 ===> H0: Mu[mujeres]-Mu[hombre]=0

##Ahora recodifiquemos sexo en una variable binaria que es igual a 1 si es mujer

mujer=recode(sexo,"1=0;2=1")
peso.regresion3=lm(peso2~mujer)
summary(peso.regresion3)

#Veamos los dos anovas.  Vean que son equivalentes.

anova(peso.regresion2)

anova(peso.regresion3)

##Analicemos supuestos del modelo peso.regresion2
#Normalidad condicional

qqPlot(peso.regresion2$residuals)
shapiro.test(peso.regresion2$residuals)

##Ahora homoscedasticidad

plot(peso.regresion2$fitted.values, peso.regresion2$residuals)

#Ahora estimemos con educacion
#Recodifiquemos educacion como lo ten�amos antes y plant�moslo como factor

educacion=recode(escola, "0=0; 1:6=1; 7:19=2; 99=NA")
educacion=as.factor(educacion)
peso.regresion4=lm(peso2~educacion)
summary(peso.regresion4)
anova(peso.regresion4)

###H0: Beta_1=Beta_2=0  ==>  H0: Mu1=Mu2=Mu3

#An�lisis de supuestos modelo peso.regresion4
#Normalidad condicional

qqPlot(peso.regresion4)
shapiro.test(peso.regresion4$residuals)

##Ahora homoscedasticidad

plot(peso.regresion4$fitted.values, peso.regresion4$residuals)

###La homoscedasticidad se puede observar tambi�n con un gr�fico boxplot

boxplot(peso2~educacion)

##A qu� ser�a equivalente un modelo de regresi�n en el que no tenemos una variable indep.
peso.regresion5=lm(peso2~1)
summary(peso.regresion5)

##H0: Beta_0=0  ==> H0: Mu=0

#An�lisis de supuestos modelo peso.regresion5
#Normalidad condicional

qqPlot(peso.regresion5$residuals)
shapiro.test(peso.regresion5$residuals)

##Ahora homoscedasticidad

plot(peso.regresion5$fitted.values, peso.regresion5$residuals)

##Por �ltimo.  Qu� tal si planteamos la siguiente prueba de hip�tesis. 
##Como hip�tesis nula, que el peso promedio en la poblaci�n es de 68Kg.


peso.regresion6=lm(peso2-68~1)
summary(peso.regresion6)

##H0: Beta_0-68=0  ===> H0: Mu=68
t.test(peso2,mu=68)


#An�lisis de supuestos modelo peso.regresion6
#Normalidad condicional

qqPlot(peso.regresion6$residuals)
shapiro.test(peso.regresion6$residuals)




