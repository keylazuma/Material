#XS-2110 M?todos Estad?sticos. Escuela de Estad?stica, UCR
#Laboratorio II. Estad?stica descriptiva 
    



#El objetivo de este laboratorio es que aprendan a utilizar R para an?lisis estad?stico b?sicos, 
#practiquen el escribir un informe, y recuerden los lineamientos b?sicos de una investigaci?n.

#Como ya se les ha dicho, R puede "jalar" archivos de otros paquetes estad?sticos.

#Utilizaremos uno de STATA, pero pueden usar de SPSS, SAS, etc.

#Supongamos que ustedes est?n desarrollando una investigaci?n sobre adultos mayores mexicanos, 
#y se plantearon los siguientes objetivos:
  
#1.	Conocer la distribuci?n por sexo y nivel de educaci?n
#2.	Conocer el peso promedio de los mexicanos por nivel de educaci?n
#3.	Conocer la proporci?n de poblaci?n urbana por sexo
#4.	Conocer la distribuci?n de la altura de la rodilla por sexo
#5.	Conocer la mediana de la altura de la rodilla por sexo
#6.	Conocer la varianza de la altura de rodilla por sexo y residencia


# Empezamos jalando el archivo.  Noten el directorio que estamos utilizando.
#Para conocer el directorio actual se debe digitar "getwd()"
#Para cambiarlo, ya saben que se utiliza "setwd()"
rm(list=ls())

setwd("C:/Users/Gilbert BC/Documents/Teletrabajo/Metodos 2022/Laboratorios/Labo 2/")


###Cuando instalen los siguientes paquetes, RStudio les va a preguntar si quieren reiniciarlo.  
###CONTESTEN QUE NO.

install.packages(c("abind","dplyr"))
install.packages(c("kable","kableExtra"))

##install.packages(c("rio","foreign","car"))
install.packages(c("haven","readr"))
###Correr la linea anterior solo si no lo instalaron en el laboratorio 1.

###Despu?s de correr este comando, les va a abrir una nueva ventana.  Ci?rrenla.  No la necesitan.

library(rio)
library(foreign)
library(car)
library(faraway)
library(abind)
library(dplyr)
library(MASS)
library(kableExtra)


library(haven)
library(readr)
antropomexicano <- read_sav("antropomexicano.sav")
attach(antropomexicano)
names(antropomexicano)

#Para algunos comandos, R requiere factores (variables categ?ricas).

table(escola)
educacion<-Recode(escola, "0=0; 1:6=1; 7:19=2; 99=NA")
antropomexico<-antropomexicano%>%
  mutate(escola<-educacion)

antropomexicano$educacion<-as.factor(educacion)

antropomexicano$sexof<-as.factor(sexo)

#verificamos que sexof y educaci?n est?n dentro de antropomexicano

names(antropomexicano)

attach(antropomexicano)
head(antropomexicano)
#Los siguientes cuadros dan una distribuci?n de frecuencias.  Ustedes escogen
# si por fila o por columna.




cuadro1<-ftable(educacion,sexof)
cuadro1
prop.table((table(educacion,sexof)),2)
round(prop.table((table(educacion,sexof)),1),2)


#La siguiente es la forma de generar una tabla de medias

(cuadro2<-tapply(peso, educacion, mean, na.rm=TRUE))


# Para que se vea m?s bonita, le pueden dar

cuadro2<-t(t(cuadro2))
cuadro2



table(urbano)


(cuadro3<-t(t(table(urbano))))



#Podemos tambi?n generar un cuadro m?s simple
#de proporciones de residencia urbana

cuadro4<-tapply(urbano, sexof, mean, na.rm=TRUE)

# Para que se vea m?s bonita, le pueden dar

(cuadro4<-t(t(cuadro4)))


#Ahora se recodifica seg?n grupos
#Calcule con tapply la mediana de altura de la rodilla por sexo
#Recodifique la variable rodilla de la siguiente forma, tomando como 
#punto la mediana. La variable nueva ser?a rodilla.nueva
# Recodifique rodilla de 0 a menos de la mediana igual a 0, y de la mediana
# al m?ximo igual a 1.


tapply(rodilla,sexof, median, na.rm=T)
summary(rodilla)



rodilla.nueva=rodilla
rodilla.nueva[sexof==1]<-Recode(rodilla[sexof==1], "0:51.9999=0; 52:120=1; 880:999=NA")
rodilla.nueva[sexof==2]<-Recode(rodilla[sexof==2], "0:46.9999=0; 47:120=1; 880:999=NA")
table(rodilla.nueva)
table(rodilla.nueva,sexof)

#Ahora variancias en una tabla cruzada.  
#La variancia promedio por sexo y residencia urbana

rodilla2<-Recode(rodilla, "880:999=NA")

tapply(rodilla2, list(sexof,urbano), var, na.rm=T)

levels(sexof)<-c("Hombre","Mujer")
urbanof<-as.factor(urbano)
levels(urbanof)<-c("Rural","Urbano")

tapply(rodilla2, list(sexof,urbanof), var, na.rm=T)


##Si ya tienen una tabla así, pueden seguir con los formatos aprendidos en Estadística Introductoria I.


cuadro5 <-round(tapply(rodilla2, list(sexof,urbanof), var, na.rm=T),2)
cuadro5 %>%
  kbl(caption = "Cuadro 5. Variancia de rodilla, por sexo, según zona") %>%
  kable_classic(full_width = F, html_font = "Arial") %>%
  row_spec(0,background ="lightgray")



#Ahora siguen ustedes.

#Los objetivos de la investigaci?n son:
  
#1.	Conocer la distribuci?n univariada (distribuci?n de frecuencias) de mexicanos por sexo y edad
#2.	Estime la circunferencia promedio por grupos de edad y sexo en forma conjunta
#3.	Defina gordos como aquellos hombres con cintura mayor a 90 cent?metros y a aquellas mujeres con cintura mayor a 85.
#4.	Calcule la variable imc, la cual es igual a peso/((altura/100)^2)
#5.	Estime el ?ndice de masa corporal mediano para hombres, seg?n si son gordos o no.


