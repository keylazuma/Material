##XS-2110 M??todos Estad??sticos

##Laboratorio de bootstrap en R. 
#UN EJEMPLO DE BOOTSTRAP CON LAS FUNCIONES DE BOOTSTRAP.
#El siguiente es el ejemplo que trae R para calcular el error est??ndar 
#de la raz??n de dos medias.
#Usaremos los datos del paquete bootstrap.  Los datos se llaman city.
library(boot)
data(city)
names(city)
city
sum(city$x)/sum(city$u)

#Es necesario definir una funci??n.  Definamos la funci??n ratio como el ratio de las medias de las variables x y u

ratio = function(datos, d)
{
  sum(datos$x[d])/sum(datos$u[d])
}

ratio(city)

#Ahora usaremos la funci??n boot para calcular el sesgo y 
#el error est??ndar

boot(city, ratio, R=999)
#FUNCIONES QUE USAN LAS FUNCIONES DE BOOTSTRAP.
#Para entender c??mo bootstrap utiliza funciones, vamos a explicar 
#notaci??n un poco m??s complicada en R.
#Suponga que se tiene un vector de enteros obs=c(2,3,7)
#Suponga adem??s que se tiene un vector x.
#Entonces, la notaci??n x[obs] es un vector con los elementos x[2], x[3], y x[7].
#En dataframes (bases de datos) se puede utilizar de la siguiente manera:
#Para vectores
x = c(10,20,30,40,50)
d = c(3,2,2)
x[d]

# Para data frames
D = data.frame(x=seq(10,50,10), y=seq(500,100,-100))
D
D[d,]

#Ahora bien, c??mo usa R esta funci??n?  
#El paquete boot de R ???llama??? repetidamente a la funci??n de estimaci??n, 
#y en cada momento, la muestra de bootstrap es generada usando 
#un vector de ??ndices enteros como el mencionado antes denominado d.

samplemean = function(x, d) {
  return(mean(x[d]))
}

samplemedian = function(x, d) {
  return(median(x[d]))
}


samplemedian(x)

#La funci??n de estimaci??n utiliza los datos en x y un vector de ??ndices en d 
#que no se ve, pues la funci??n boot es la que lo generar??.  En cada momento, 
#los datos x son los mismos, pero la muestra de bootstrap ser?? diferente.
#En cada llamado, el paquete boot genera un nuevo conjunto de ??ndices d.  
#La notaci??n x[d] permite generar un nuevo vector (la muestra bootstrap), 
#la cual es dada a la funci??n mean() o median().  
#Esto refleja muestreo con reemplazo desde el vector original de datos.
x
b = boot(x, samplemedian, R=1000)           # 1000 replicas

#El objeto b que es estimado por boot() tiene una serie de subobjetos.  
#Escriba lo siguiente para que vea que genera.

b
sd(b$t[,1])
mean(b$t[,1])

ci = boot.ci(b, type="all")
ci

hist(b$t[,1])

#El subobjeto b$t es una matriz que contiene 1000 filas con todos los resultados 
#de la estimaci??n.  La primera columna en ella es la mediana remuestreada.
plot(b)
#Haciendo ejemplos con datos que uno tiene (bases de datos).
#Calcularemos un intervalo bootstrap para la raz??n de dos desviaciones est??ndar.

sdratio = function(D, d) {
  E=D[d,]
  return(sd(E$x)/sd(E$y))
}

x = runif(100)
y = 2*runif(100)
D = data.frame(x, y)

b = boot(D, sdratio, R=1000)
b

ci = boot.ci(b, type="all")
ci

#Ejemplo con la media acotada
trimmedmean = function(x, d, trim=0) {
  return(mean(x[d], trim/length(x)))
}
b = boot(x, trimmedmean, R=1000, trim=5)
b

#Esta funci??n agreg?? el comando trim para seleccionar cu??ntas observaciones se acotan.
##Pr??ctica de bootstrap 
##1.	Genere primero una variable x que contenga una muestra de tama??o n=100 de una distribuci??n 
##aleatoria uniforme continua entre 0 y 100 (2 ptos.).
##2.	Determine ahora cu??ntas letras tiene su nombre (por ej., ???Gilbert??? tiene 7) y cu??ntas 
###letras tiene su apellido (por ej., ???Brenes??? tiene 6).  
##Ll??mele j al n??mero de letras de su nombre y k al n??mero de letras de su apellido.  
##Escriba claramente cu??nto es j y cu??nto es k. (1 ptos.)

##3.	Genere ahora una variable y que contenga una muestra de tama??o n=100 de una distribuci??n exponencial 
##con tasa igual a j/1000 + x*k/1000  (Por ejemplo, en mi caso, la tasa de la exponencial se escribir??a rate=7/1000+x*6/1000. (1 ptos.).

##4.	Estime una correlaci??n de Pearson entre x y y (2 ptos.)

##5.	Estime el error est??ndar de bootstrap y el sesgo de bootstrap con 1000 remuestreos para la correlaci??n (3 ptos.)
##6.	Estime un intervalo de confianza bootstrap de percentiles (intervalo de confianza no param??trico) con 1000 remuestreos para la correlaci??n (2 ptos.)

##7.	Estime un intervalo de confianza bootstrap ???normal??? (intervalo de confianza param??trico) con 1000 remuestreos para la correlaci??n (2 ptos.)
##8.	Repita los pasos del 4 al 7 con una correlaci??n de rangos de Spearman y con una tao de Kendall. 
##9.	Compare los intervalos de confianza param??tricos de las tres medidas de asociaci??n, y los intervalos de confianza no param??tricos de las tres medidas de asociaci??n.


x <- runif(100,min=0,max=100)
y <- rexp(100,rate=7/1000+x*6/1000)

XY=data.frame(cbind(x,y))
