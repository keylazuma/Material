###LABORATORIO DE ANALISIS DE VARIANCIA


###El objetivo de este laboratorio es realizar el ejercicio sobre crecimiento de jacarandas, 
###cuyos datos est�n en el libro de Guti�rrez Espeleta (1995). 

###"Supongamos que se quiere determinar los efectos de cinco t�cnicas de preparaci�n de sitio 
###sobre el crecimiento juvenil de pl�ntulas de Jacaranda copaia (gallinazo) cuando se planta 
###en monocultivo.  Se establecen 25 parcelas y cada t�cnica de preparaci�n es asignada 
###a 5 parcelas seleccionadas al azar.  Las parcelas se plantan a mano y al final del tercer a�o 
###se mide la altura de cada uno de los 25 �rboles.

###1)	Haga un an�lisis exploratorio de variabilidad y normalidad con gr�ficos de caja, 
###y despu�s haga pruebas de homogeneidad de variancias (levene y bartlett) y de normalidad condicional.



#Los datos
jacaranda=c(4.5, 4.8, 3.9, 3.3, 4.2, 4.2, 4.2, 3.6, 3.9, 3.6, 3.6, 3.9, 3.3, 3.0, 3.6, 3.9, 4.5, 3.6, 3.6, 3.0, 3.9, 4.2, 3.0, 3.3, 3.3)
grupofactor=as.factor(c(1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5))
##bloque=as.factor(c(1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4,5,5,5,5,5))

#Los datos en un data frame
jacar=data.frame(cbind(jacaranda,grupofactor) )

#An�lisis exploratorio de variabilidad
etiquetas=c("S1","S2","S3","S4","S5")
boxplot(jacaranda~grupofactor, names=etiquetas)

#Pruebas de homogeneidad de varianzas
library(car) #Necesaria para usar la prueba de levene

##H0: Sigma1=sigma2=sigma3=sigma4=sigma5
###H1: Al menos un sigma_i<>sigma_j

leveneTest(jacaranda, grupofactor)

bartlett.test(jacaranda, grupofactor)

#Primer comando:  lm
anova1=lm(jacaranda~grupofactor)
anova1

#An�lisis de residuos.  Aqu� se estudia normalidad.
qqPlot(anova1$residuals)

shapiro.test(anova1$residuals)

plot(anova1$fitted.values,anova1$residuals)

##summary(anova1)

###H0: Mu1=Mu2=Mu3=Mu4=Mu5
###H1: Al menos un MU_i <> Mu_j
anova(anova1)

1-pf(5.8514,4,20)

#El otro commando es el aov.  Permite utilizar el comando TukeyHSD
anova3=aov(jacaranda~grupofactor)
anova(anova3)
TukeyHSD(anova3)


##Qu� pasa cuando se viola el supuesto de homoscedasticidad.
#Se usa el siguiente comando.
###H0: Mu1=Mu2=Mu3=Mu4=Mu5
###H1: Al menos un MU_i <> Mu_j


oneway.test(jacaranda~grupofactor)

###Y si se rechaza la H0, se empieza a hacer un ANDEVA heterosced�stico para cada par, corrigiendo el p-value

###Los p-value se comparan con 0.05/10, o sea, se rechaza la igualdad de medias si
# el p-value en cada prueba es menor a 0.005.  
##Se divide el alfa entre 10 porque hay 10 comparaciones.  Si fueran solo 3 comparaciones
# se divide nada m�s entre 3.

(num.grupos=dim(table(grupofactor)))

matriz.dif.medias=matrix(rep(NA,num.grupos^2),nrow=num.grupos)
matriz.pvalues=matrix(rep(NA,num.grupos^2),nrow=num.grupos)

(total.cells=choose(num.grupos,2))  ###Combinatoria 2 de 5, que ser�an todas las comparaciones por realizar.

for (i in 1:num.grupos) {
  
  for (j in 1:num.grupos) {
    
    if (i==j) {
      
      matriz.dif.medias[i,j]=NA
      matriz.pvalues[i,j]=NA
      
    }
    else {
      
      matriz.dif.medias[i,j]=mean(jacaranda[grupofactor==i])-mean(jacaranda[grupofactor==j])
      prueba=oneway.test(jacaranda[grupofactor==i | grupofactor==j]~grupofactor[grupofactor==i | grupofactor==j])
      multiplic=prueba$p.value*total.cells
      ifelse(multiplic>1,  matriz.pvalues[i,j]<-1, matriz.pvalues[i,j]<-multiplic)
      
    }
    
    
  }
  
  
  
}

colnames(matriz.dif.medias)=etiquetas
rownames(matriz.dif.medias)=etiquetas

colnames(matriz.pvalues)=etiquetas
rownames(matriz.pvalues)=etiquetas



matriz.dif.medias
matriz.pvalues



#Que pasa cuando se viola el supuesto de normalidad o de homoscedasticidad, #especialmente por valores extremos

kruskal.test(jacaranda~grupofactor)

###Si se rechaza H0 en el Kruskal Wallis, ser recomienda usar la prueba de Dunn 
###con el m�todo de Bonferroni.

library(dunn.test)
dunn.test(jacaranda,grupofactor,method="bonferroni")
