library("ggplot2")
setwd("~/Nicole UCR/Tercer año/Demografía/Práctica 2")
Tabla2 <- read_csv("~/Nicole UCR/Tercer año/Demografía/Práctica 2/Tabla2.csv")

class(Tabla2$Edad)

ggplot(Tabla2, aes(Edad, Total) ) +
  geom_point() +
  geom_smooth(method = 'loess', span=0.25)

ggplot(Tabla2, aes(Edad, Total) ) +
  geom_point() +
  geom_smooth(method = 'loess', span=0.15)